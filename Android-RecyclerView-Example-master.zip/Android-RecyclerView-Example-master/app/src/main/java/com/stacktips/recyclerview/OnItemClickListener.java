package com.stacktips.recyclerview;

/**
 * Created by Nilanchala Panigrahy on 10/25/16.
 */

public interface OnItemClickListener {
    void onItemClick(FeedItem item);
}
