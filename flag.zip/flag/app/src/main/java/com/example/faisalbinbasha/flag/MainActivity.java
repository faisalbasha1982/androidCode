package com.example.faisalbinbasha.flag;

import android.graphics.drawable.ShapeDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button v;
    private Button v1;
    private boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        v = (Button)findViewById(R.id.view1);
        v1 = (Button) findViewById(R.id.view2);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(flag) {
                    v.setBackgroundResource(R.drawable.circle2);
                    flag = false;
                }
                else {
                    v.setBackgroundResource(R.drawable.circle);
                    flag = true;
                }

            }
        });


    }
}
