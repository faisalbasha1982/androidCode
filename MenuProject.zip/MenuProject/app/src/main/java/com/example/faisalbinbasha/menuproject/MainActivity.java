package com.example.faisalbinbasha.menuproject;

import android.app.ActionBar;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button button1;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);

        button1 = (Button) findViewById(R.id.btn1);
        button2 = (Button) findViewById(R.id.btn2);


        if (toolbar != null) {
            setSupportActionBar(toolbar);

            //getSupportActionBar().setTitle(this.getResources().getString(R.string.app_name));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

//            Menu m = (Menu)toolbar.getMenu();
//            MenuItem mt = m.getItem(R.id.home);
//
//            mt.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
//                @Override
//                public boolean onMenuItemClick(MenuItem menuItem) {
//
//                    int id = menuItem.getItemId();
//
//                    if(id==R.id.home)
//                        button2.setVisibility(View.VISIBLE);
//
//                    return false;
//                }
//            });


            toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {

                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    int id = item.getItemId();

                    onOptionsItemSelected(item);

                    //Toast.makeText(MainActivity.this, "HEllo from toolbar menu", Toast.LENGTH_SHORT).show();

                    //if(id == R.id.home)
                    //button2.setVisibility(View.VISIBLE);

                    //if(id == R.id.addition)
                        //button2.setVisibility(View.INVISIBLE);

                    return false;
                }
            });

            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getApplicationContext(),"hello from button1",Toast.LENGTH_SHORT).show();
                    button2.setVisibility(view.INVISIBLE);
                }
            });

            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getApplicationContext(),"hello from button2",Toast.LENGTH_SHORT).show();

                }
            });

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            button2.setVisibility(View.VISIBLE);
        }
        return super.onOptionsItemSelected(item);
    }

}
